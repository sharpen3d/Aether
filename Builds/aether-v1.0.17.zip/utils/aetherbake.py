import bpy
import os
import platform
import subprocess
import json
import numpy as np
from mathutils import Vector

# ---------- Utility Functions ----------

def store_render_settings(scene):
    return {
        'engine': scene.render.engine,
        'resolution_x': scene.render.resolution_x,
        'resolution_y': scene.render.resolution_y,
        'samples': scene.cycles.samples,
        'view_transform': scene.view_settings.view_transform,
        'color_mode': scene.render.image_settings.color_mode,
        'color_depth': scene.render.image_settings.color_depth,
        'file_format': scene.render.image_settings.file_format,
        'use_denoising': scene.cycles.use_denoising,
        'use_motion_blur': scene.render.use_motion_blur,
        'film_transparent': scene.render.film_transparent,
    }

def store_material_data(obj):
    mesh = obj.data
    material_slots = list(mesh.materials)
    poly_material_indices = [poly.material_index for poly in mesh.polygons]
    return material_slots, poly_material_indices

def restore_material_data(obj, material_slots, poly_material_indices):
    mesh = obj.data
    mesh.materials.clear()
    for mat in material_slots:
        mesh.materials.append(mat)
    for poly, mat_index in zip(mesh.polygons, poly_material_indices):
        poly.material_index = mat_index


def restore_render_settings(scene, settings):
    for key, value in settings.items():
        if hasattr(scene.render, key):
            setattr(scene.render, key, value)
        elif hasattr(scene.cycles, key):
            setattr(scene.cycles, key, value)
        elif key == 'view_transform':
            scene.view_settings.view_transform = value


def snapshot_multires(*objs):
    """For each object, find every Multires modifier and snapshot its
    `levels` / `render_levels` / `sculpt_levels`. Then push the modifier
    to viewport=0 + render_levels=total so the bake reads the
    fully-detailed sculpted surface while UVs stay anchored to the base
    mesh.

    Returns a list of (modifier, prev_levels, prev_render_levels,
    prev_sculpt_levels) tuples to be passed back to `restore_multires`.

    Works for both common workflows:
        - Multires on the lowpoly target (single-object mode): bake
          reads multires-displaced surface, writes to base UVs.
        - Multires on the highpoly source (selected-to-active): the
          highpoly's full sculpt detail is sampled when projecting from
          source -> target.

    Edge case noted but not addressed here: position bake combined with
    multires on the lowpoly will produce position values outside [0,1]
    for sculpted areas, because `normalize_to_unit_cube` measures only
    the base mesh bounds. The EMIT bake won't clamp, so the EXR will
    contain the extended values, but the importer's Map Range decode
    assumes [0,1] input. Sculpt on the highpoly for accurate positions.
    """
    snapshots = []
    for obj in objs:
        if obj is None:
            continue
        for mod in obj.modifiers:
            if mod.type == 'MULTIRES':
                snapshots.append((
                    mod,
                    mod.levels,
                    mod.render_levels,
                    mod.sculpt_levels,
                ))
                mod.levels = 0
                mod.render_levels = mod.total_levels
    return snapshots


def restore_multires(snapshots):
    for mod, lv, rlv, slv in snapshots:
        try:
            mod.levels = lv
            mod.render_levels = rlv
            mod.sculpt_levels = slv
        except Exception:
            # Modifier may have been removed by user code mid-bake; we'd
            # rather swallow than surface a confusing restore error after
            # the bakes already succeeded.
            pass

def apply_bake_render_settings(scene, resolution):
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 1
    scene.cycles.use_denoising = False
    scene.render.use_motion_blur = False
    scene.render.film_transparent = True
    scene.render.resolution_x = resolution
    scene.render.resolution_y = resolution
    scene.render.resolution_percentage = 100
    scene.render.image_settings.color_mode = 'RGB'
    scene.render.image_settings.color_depth = '16'
    scene.render.image_settings.file_format = 'OPEN_EXR'
    scene.view_settings.view_transform = 'Raw'

def should_use_selected_to_active(scene, obj, source):
    return scene.aether_use_highpoly and source and source != obj

def prepare_bake_selection(target, source=None, use_selected_to_active=False):
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    if use_selected_to_active and source and source != target:
        source.hide_set(False)
        target.hide_set(False)
        source.select_set(True)
        target.select_set(True)
        bpy.context.view_layer.objects.active = target
    else:
        target.hide_set(False)
        target.select_set(True)
        bpy.context.view_layer.objects.active = target

def create_bake_image(name, resolution, float_buffer=True):
    img = bpy.data.images.new(name, width=resolution, height=resolution, float_buffer=float_buffer)
    img.colorspace_settings.name = 'Non-Color'
    img.alpha_mode = 'NONE'
    return img

def assign_bake_material(obj, img, shader_fn=None):
    mat = bpy.data.materials.new("__AetherBakeTemp")
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    img_node = nodes.new("ShaderNodeTexImage")
    img_node.image = img
    img_node.select = True
    nodes.active = img_node

    output = nodes.new("ShaderNodeOutputMaterial")

    if shader_fn:
        shader_fn(nodes, links, output)

    obj.data.materials.clear()
    obj.data.materials.append(mat)
    return mat, img_node

def bake_image(scene, bake_type='NORMAL', normal_space='TANGENT', use_selected_to_active=False):
    scene.cycles.bake_type = bake_type
    bake = scene.render.bake
    bake.use_selected_to_active = use_selected_to_active
    bake.use_pass_direct = False
    bake.use_pass_indirect = False

    # UV-island padding. Default `EXTEND` smears the last edge texel
    # outward as a flat ramp, which lights up as a hard step under
    # downstream derivatives (the curvature pass especially picks it up
    # as a UV-island outline). `ADJACENT_FACES` walks across the
    # topological seam and fills the margin with samples from the
    # neighboring face, which is what we want — seamless across UV
    # islands at the cost of slightly slower bakes. Available in 4.x.
    # Margin of 16 px covers our curvature blur radius (default 4 px)
    # plus comfortable headroom; bump only if soft_radius gets cranked.
    bake.margin = 16
    bake.margin_type = 'ADJACENT_FACES'

    # Cage / ray-projection controls govern how rays start from the lowpoly
    # surface and how far they march before terminating. They apply to ANY
    # selected-to-active bake (NORMAL, AO, custom EMIT/DIFFUSE), not just
    # NORMAL. Previously these were only set on the NORMAL branch, which is
    # why AO came out solid black under highpoly→lowpoly: rays started at
    # cage_extrusion=0 (i.e. exactly on the lowpoly surface, often inside
    # the highpoly cage) and self-occluded immediately.
    if use_selected_to_active:
        bake.use_cage = False
        bake.cage_extrusion = 0.4
        bake.max_ray_distance = 0.8
    if bake_type == 'NORMAL':
        bake.normal_space = normal_space
    bpy.ops.object.bake(type=bake_type)

def bake_map(obj, resolution, filepath, map_type, normal_space='TANGENT', source=None):
    scene = bpy.context.scene
    
    original_materials, poly_indices = store_material_data(obj)
    if source:
        source_materials, source_indices = store_material_data(source)
    else:
        source_materials, source_indices = None, None

    
    is_tangent_normal = map_type == 'NORMAL' and normal_space == 'TANGENT'
    is_object_normal = map_type == 'NORMAL' and normal_space == 'OBJECT'
    is_ao = map_type == 'AO'

    use_float = not is_tangent_normal
    img = create_bake_image(obj.name + "_" + map_type, resolution, float_buffer=True)
    img.filepath_raw = filepath
    img.file_format = 'OPEN_EXR'
    scene.render.image_settings.file_format = img.file_format
    scene.render.image_settings.color_depth = '16'
    scene.render.image_settings.color_mode = 'RGB'
    img.colorspace_settings.name = 'Non-Color'

    if is_ao:
        scene.cycles.samples = 256
        scene.cycles.use_denoising = True
    elif map_type == 'NORMAL':
        # 1 sample per texel = no AA at polygon edges within a texel,
        # so vertex-normal interpolation steps appear as visible polygon
        # facets in the EXR (and get amplified into "polygons showing
        # through" in the curvature derivative). Cycles supersamples
        # the bake by `samples` and averages, so 16 dilutes the step
        # function to a smooth ramp. Cheap — NORMAL bake itself is
        # essentially deterministic per shading point, so the cost is
        # purely in extra ray casts at texel edges.
        scene.cycles.samples = 16

    # AO needs a real Surface link on whichever material Cycles is sampling
    # at the shading point, otherwise the surface is treated as transparent
    # and the AO integrator returns 0 (solid black EXR). For NORMAL and
    # OBJECT-space normal bakes Cycles synthesizes the geometry surface
    # internally, so the empty material is fine.
    #   - selected_to_active AO: shading point lives on the highpoly, so
    #     the white-diffuse goes on `source` and the lowpoly carries only
    #     the image receiver.
    #   - single-object AO: same material does both.
    shader_mat = None
    if is_ao:
        if source:
            shader_mat, _ = assign_bake_material(source, None, shader_white_diffuse)
            mat, img_node = assign_bake_material(obj, img)
        else:
            mat, img_node = assign_bake_material(obj, img, shader_white_diffuse)
    else:
        mat, img_node = assign_bake_material(obj, img)

    prepare_bake_selection(obj, source, use_selected_to_active=bool(source))
    bake_image(scene, bake_type=map_type, normal_space=normal_space, use_selected_to_active=bool(source))
    img.save()
    bpy.data.images.remove(img)
    bpy.data.materials.remove(mat)
    if shader_mat is not None:
        bpy.data.materials.remove(shader_mat)

    restore_material_data(obj, original_materials, poly_indices)
    if source and source_materials and source_indices:
        restore_material_data(source, source_materials, source_indices)


def normalize_to_unit_cube(obj):
    import bmesh
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    local_coords = [v.co.copy() for v in bm.verts]
    min_corner = Vector((min(v[i] for v in local_coords) for i in range(3)))
    max_corner = Vector((max(v[i] for v in local_coords) for i in range(3)))
    dims = max_corner - min_corner
    scale = Vector((1.0 / max(dims.x, 1e-6), 1.0 / max(dims.y, 1e-6), 1.0 / max(dims.z, 1e-6)))
    for v in bm.verts:
        v.co -= min_corner
        v.co.x *= scale.x
        v.co.y *= scale.y
        v.co.z *= scale.z
    bm.to_mesh(mesh)
    bm.free()
    return min_corner, max_corner

def unnormalize_from_bounds(obj, min_corner, max_corner):
    import bmesh
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    dims = max_corner - min_corner
    for v in bm.verts:
        v.co.x *= dims.x
        v.co.y *= dims.y
        v.co.z *= dims.z
        v.co += min_corner
    bm.to_mesh(mesh)
    bm.free()

def bake_custom_map(obj, resolution, filepath, shader_fn, source=None,
                    grayscale=False, debug=False, bake_type='DIFFUSE'):
    """Bake a custom shader output to an EXR.

    bake_type:
        'DIFFUSE' - reads BSDF Base Color via the diffuse color pass.
                    Suitable for shaders that already constrain output to
                    [0,1] (e.g. curvature). DO NOT use for raw position
                    output; Principled BSDF clamps Base Color to [0,1].
        'EMIT'    - reads ShaderNodeEmission.Color directly with no
                    BSDF interaction or color-pass scaling. Use this for
                    position, world normals, or anything where the shader
                    produces values that must pass through unmodified.
    """
    scene = bpy.context.scene

    original_materials, poly_indices = store_material_data(obj)
    if source:
        source_materials, source_indices = store_material_data(source)
    else:
        source_materials, source_indices = None, None

    use_float = True
    img = create_bake_image(obj.name + "_Bake", resolution, float_buffer=use_float)
    img.filepath_raw = filepath
    img.file_format = 'OPEN_EXR' if use_float else 'PNG'
    scene.render.image_settings.file_format = img.file_format
    scene.render.image_settings.color_depth = '16' if use_float else '8'
    scene.render.image_settings.color_mode = 'RGB' if not grayscale else 'BW'
    img.colorspace_settings.name = 'Non-Color'

    if source:
        shader_mat, _ = assign_bake_material(source, None, shader_fn)
        _, img_node = assign_bake_material(obj, img)
    else:
        shader_mat, _ = assign_bake_material(obj, img, shader_fn)

    prepare_bake_selection(obj, source, use_selected_to_active=bool(source))
    bpy.ops.object.editmode_toggle()
    bpy.ops.object.editmode_toggle()

    if not debug:
        scene.cycles.use_denoising = grayscale
        bake_image(scene, bake_type=bake_type, use_selected_to_active=bool(source))
        img.save()
        bpy.data.images.remove(img)
        bpy.data.materials.remove(shader_mat)
    else:
        print("[DEBUG] Shader preview active")
        bpy.context.space_data.shading.type = 'MATERIAL'

    restore_material_data(obj, original_materials, poly_indices)
    if source and source_materials and source_indices:
        restore_material_data(source, source_materials, source_indices)


def derive_curvature_from_normal_obj(normal_filepath, curvature_filepath,
                                     contrast=2.0, hard_weight=0.65,
                                     soft_radius=4):
    """Compute a curvature map from a previously-baked object-space normal
    map. This is a post-process — no Cycles bake — modeled on Substance
    Painter's "Curvature from World Space Normal" baker.

    Why this and not Geometry.Pointiness:
        Pointiness is a per-shading-point edge-angle measurement, so its
        resolution is bounded by mesh density. Even with aggressive
        subdivision the result is grainy and never matches SP. Object-space
        normals are continuous across the texture grid, so spatial
        derivatives produce a clean per-texel curvature regardless of
        underlying mesh density. Side benefit: this works identically for
        single-object and highpoly→lowpoly bakes because it only consumes
        the final EXR — there's no bake-time projection setup that could
        diverge between the two modes.

    Math:
        curvature ≈ ∂N.x/∂u + ∂N.y/∂v   (divergence of the XY projection
        of the unit normal field). Positive values mark convex ridges,
        negative values mark concave creases. We compute this at two
        scales — sharp (raw 3×3 finite difference) for edge highlights
        and broad (after a box blur) for cavity shading — and mix them
        via `hard_weight`. Final remap centers flat surfaces at 0.5 so
        the texture-painting workflow can use it as a bidirectional mask.

    Notes / caveats:
        - Inherits any seam or cage artifacts from the source normal-obj
          bake. If they're visible in the .exr, they'll be visible (and
          amplified) in curvature. Usually fine at 2K with 256 samples.
        - The blur and derivative don't know about UV island borders, so
          you'll get a faint dark/light halo at island edges. Substance
          Painter has the same artifact; their solution is UV-aware
          padding which we can add later if it bites.
    """
    img = bpy.data.images.load(normal_filepath, check_existing=False)
    img.colorspace_settings.name = 'Non-Color'
    try:
        w, h = img.size
        if w == 0 or h == 0:
            raise RuntimeError(f"Normal map {normal_filepath} has zero size")

        buf = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(buf)
        buf = buf.reshape((h, w, 4))

        # Decode unsigned [0,1] → signed [-1,1]. Object-space normals are
        # stored that way per our shader_position-style remap convention.
        n = buf[:, :, :3] * 2.0 - 1.0

        hard = _curvature_divergence(n)
        soft = _curvature_divergence(_box_blur_2d(n, soft_radius)) if soft_radius > 0 else hard

        curvature = hard * hard_weight + soft * (1.0 - hard_weight)

        # Center on 0.5 = flat. The 4× scalar is a sensitivity coefficient
        # tuned to map "obvious-but-not-extreme" curvature onto the visible
        # range; combined with `contrast` the user can dial intensity.
        curvature = 0.5 + curvature * contrast * 4.0
        np.clip(curvature, 0.0, 1.0, out=curvature)
    finally:
        bpy.data.images.remove(img)

    out = np.empty((h, w, 4), dtype=np.float32)
    out[:, :, 0] = curvature
    out[:, :, 1] = curvature
    out[:, :, 2] = curvature
    out[:, :, 3] = 1.0

    out_img = bpy.data.images.new(
        "__curvature_temp", width=w, height=h, float_buffer=True,
    )
    out_img.colorspace_settings.name = 'Non-Color'
    out_img.alpha_mode = 'NONE'
    out_img.pixels.foreach_set(out.ravel())
    out_img.filepath_raw = curvature_filepath
    out_img.file_format = 'OPEN_EXR'

    scene = bpy.context.scene
    prev_color_mode = scene.render.image_settings.color_mode
    scene.render.image_settings.color_mode = 'BW'
    try:
        out_img.save()
    finally:
        scene.render.image_settings.color_mode = prev_color_mode
        bpy.data.images.remove(out_img)


def _curvature_divergence(n):
    """Scalar curvature field from a (H, W, 3) normal field.

    Uses central differences for ∂N.x/∂u and ∂N.y/∂v. Border pixels are
    left at zero — they'd be filled by edge-clamping anyway and the
    halo is cheaper to ignore than to mask. Returns (H, W) float32.
    """
    nx = n[:, :, 0]
    ny = n[:, :, 1]

    dnx_du = np.zeros_like(nx)
    dny_dv = np.zeros_like(ny)

    dnx_du[:, 1:-1] = (nx[:, 2:] - nx[:, :-2]) * 0.5
    dny_dv[1:-1, :] = (ny[2:, :] - ny[:-2, :]) * 0.5

    return dnx_du + dny_dv


def _box_blur_2d(img, radius):
    """Separable box blur via cumulative sum — O(N) per axis regardless
    of `radius`. Matches scipy.ndimage.uniform_filter for kernel size
    2*radius+1, but without the dependency.

    `img` shape (H, W, C). Edge-extends rather than zero-pads so the
    blur doesn't darken texture borders.
    """
    if radius <= 0:
        return img.copy()

    k = 2 * radius + 1

    pad = np.pad(img, ((0, 0), (radius + 1, radius), (0, 0)), mode='edge')
    csum = np.cumsum(pad, axis=1, dtype=np.float32)
    h_blurred = (csum[:, k:, :] - csum[:, :-k, :]) / k

    pad = np.pad(h_blurred, ((radius + 1, radius), (0, 0), (0, 0)), mode='edge')
    csum = np.cumsum(pad, axis=0, dtype=np.float32)
    blurred = (csum[k:, :, :] - csum[:-k, :, :]) / k

    return blurred



# ---------- Shader Templates ----------

def shader_white_diffuse(nodes, links, output_node):
    """Neutral surface used for AO bake.

    Cycles AO bake computes hemispheric occlusion *at* a surface point.
    Without a Surface link on the bake material, the object is treated as
    transparent — rays pass through without producing a shading point,
    AO integrates to zero, and the EXR comes out solid black. A simple
    white Diffuse gives Cycles a valid surface to bake AO at; the diffuse
    color isn't sampled by the AO pass itself, only its existence matters.
    """
    diffuse = nodes.new("ShaderNodeBsdfDiffuse")
    diffuse.inputs["Color"].default_value = (1.0, 1.0, 1.0, 1.0)
    links.new(diffuse.outputs["BSDF"], output_node.inputs["Surface"])


def shader_position(nodes, links, output_node):
    # Object-space position via Texture Coordinate, not world-space via
    # Geometry. `normalize_to_unit_cube` mutates the LOCAL mesh data to
    # [0,1]; Geometry.Position would re-introduce obj.matrix_world (any
    # rotation, scale, or location offset) and push channels out of range.
    # In particular, a flipping rotation (180° around Y or Z) puts world X
    # in [-1, 0], which reads as solid black on a Raw EXR viewer even
    # though the data is technically present.
    #
    # Emission rather than Principled BSDF for the same reason as before:
    # Principled.Base Color is internally clamped to [0,1] before
    # contributing to the diffuse pass. EMIT bake samples emission color
    # directly with no BSDF or color-pass interaction, so the [0,1]
    # object-space coords pass through unmodified into the float EXR and
    # the importer's Map Range nodes decode them back to world coords via
    # the bounds JSON.
    texcoord = nodes.new("ShaderNodeTexCoord")
    emission = nodes.new("ShaderNodeEmission")
    links.new(texcoord.outputs["Object"], emission.inputs["Color"])
    links.new(emission.outputs["Emission"], output_node.inputs["Surface"])


# ---------- Operators and UI ----------

class AETHER_OT_bake_source_maps(bpy.types.Operator):
    bl_idname = "aether.bake_source_maps"
    bl_label = "Bake Source Maps"

    def execute(self, context):
        scene = context.scene
        obj = scene.aether_target_obj
        source = scene.aether_source_obj
        resolution = int(scene.aether_bake_resolution)
        base_dir = bpy.path.abspath(f"//{obj.name}/source_maps")
        os.makedirs(base_dir, exist_ok=True)

        use_selected_to_active = should_use_selected_to_active(scene, obj, source)

        settings = store_render_settings(scene)
        apply_bake_render_settings(scene, resolution)

        # Push any Multires modifier on target/source to its render level
        # so the bake samples the fully-sculpted surface. Restored in the
        # finally below regardless of how the bake block exits.
        multires_snapshots = snapshot_multires(obj, source)

        try:
            prepare_bake_selection(obj)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            if obj.type == 'MESH' and obj.data.uv_layers.active:
                bpy.ops.uv.export_layout(filepath=os.path.join(base_dir, f"{obj.name}_uv.png"), size=(resolution, resolution), opacity=1.0)
            bpy.ops.object.mode_set(mode='OBJECT')

            # Filenames mirror file_format='OPEN_EXR' set in bake_map /
            # bake_custom_map. Importer at sourceimporter.py:60 already
            # accepts both .png and .exr suffixes, so renaming is non-
            # breaking for existing source_maps folders that still hold
            # the old (mislabeled) .png files.
            bake_source = source if use_selected_to_active else None
            bake_map(obj, resolution, os.path.join(base_dir, f"{obj.name}_normal.exr"),
                     'NORMAL', 'TANGENT', bake_source)
            bake_map(obj, resolution, os.path.join(base_dir, f"{obj.name}_normal-obj.exr"),
                     'NORMAL', 'OBJECT', bake_source)
            bake_map(obj, resolution, os.path.join(base_dir, f"{obj.name}_ao.exr"),
                     'AO', 'TANGENT', bake_source)
            # Curvature is derived from the normal-obj EXR we just baked
            # — it's a numpy post-process, not a Cycles bake. This is
            # deliberately *after* bake_map(..., 'NORMAL', 'OBJECT', ...)
            # so the source file exists; do not reorder without moving
            # this call.
            derive_curvature_from_normal_obj(
                os.path.join(base_dir, f"{obj.name}_normal-obj.exr"),
                os.path.join(base_dir, f"{obj.name}_curvature.exr"),
                contrast=scene.aether_curvature_contrast,
                hard_weight=scene.aether_curvature_hard_weight,
                soft_radius=scene.aether_curvature_soft_radius,
            )

            # Position pipeline: temporarily normalize the lowpoly to a
            # unit cube so the EMIT bake's float output stays in [0,1]
            # (importer's Map Range nodes decode it back to world coords
            # from the bounds JSON). The normalize step mutates mesh data
            # in place; if anything throws between normalize and
            # unnormalize, the lowpoly is left in unit-cube space — hence
            # the try/finally.
            min_bound, max_bound = normalize_to_unit_cube(obj)
            try:
                bake_custom_map(
                    obj, resolution,
                    os.path.join(base_dir, f"{obj.name}_position.exr"),
                    shader_position, source=None, grayscale=False,
                    bake_type='EMIT',
                )
            finally:
                unnormalize_from_bounds(obj, min_bound, max_bound)
            bounds_data = {
                "min": list(min_bound),
                "max": list(max_bound)
            }
            with open(os.path.join(base_dir, f"{obj.name}_position_bounds.json"), 'w') as f:
                json.dump(bounds_data, f, indent=4)
            
            bpy.context.scene.render.engine = 'BLENDER_EEVEE'
            bpy.context.scene.view_layers["ViewLayer"].use = False

        finally:
            restore_multires(multires_snapshots)
            restore_render_settings(scene, settings)

            # set up material authoring scene
            context.scene.export_settings.source_object = obj
            context.scene.custom_object_name = obj.name + "_mat"
            #bpy.ops.exportmap.create_bake_scene()

        return {'FINISHED'}

class AETHER_OT_open_export_dir(bpy.types.Operator):
    bl_idname = "aether.open_export_dir"
    bl_label = "Open Export Directory"

    def execute(self, context):
        obj = context.scene.aether_target_obj
        path = bpy.path.abspath(f"//{obj.name}/source_maps")
        if platform.system() == 'Windows':
            os.startfile(path)
        elif platform.system() == 'Darwin':
            subprocess.call(["open", path])
        else:
            subprocess.call(["xdg-open", path])
        return {'FINISHED'}

class AETHER_PT_bake_panel(bpy.types.Panel):
    bl_label = "Source Map Baking"
    bl_idname = "AETHER_PT_bake_panel"
    bl_space_type = 'VIEW_3D' 
    bl_region_type = 'UI'  
    bl_category = 'Aether'    

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene, "aether_target_obj")
        layout.prop(scene, "aether_use_highpoly")
        if scene.aether_use_highpoly:
            layout.prop(scene, "aether_source_obj")
        layout.prop(scene, "aether_bake_resolution")

        curvature_box = layout.box()
        curvature_box.label(text="Curvature", icon='SCULPTMODE_HLT')
        curvature_box.prop(scene, "aether_curvature_contrast", slider=True)
        curvature_box.prop(scene, "aether_curvature_hard_weight", slider=True)
        curvature_box.prop(scene, "aether_curvature_soft_radius", slider=True)

        layout.operator("aether.bake_source_maps")
        layout.operator("aether.open_export_dir", icon='FILE_FOLDER')

# ---------- Registration ----------

def register():
    bpy.utils.register_class(AETHER_OT_bake_source_maps)
    bpy.utils.register_class(AETHER_OT_open_export_dir)
    bpy.utils.register_class(AETHER_PT_bake_panel)
    bpy.types.Scene.aether_target_obj = bpy.props.PointerProperty(type=bpy.types.Object)
    bpy.types.Scene.aether_source_obj = bpy.props.PointerProperty(type=bpy.types.Object)
    bpy.types.Scene.aether_use_highpoly = bpy.props.BoolProperty(name="From High Res", default=False)
    bpy.types.Scene.aether_bake_resolution = bpy.props.EnumProperty(
        name="Resolution",
        items=[(str(x), f"{x}x{x}", "") for x in [512, 1024, 2048, 4096]],
        default='2048'
    )
    # Overall sensitivity multiplier on the curvature derivation. The 4×
    # base coefficient inside derive_curvature_from_normal_obj puts a
    # value of 1.0 in a "balanced" zone; below 1 softens, above 1 pushes
    # mid-grey toward black/white edges. Soft cap at 4 to discourage the
    # blown-out look — hard cap at 8 for users who really want it.
    bpy.types.Scene.aether_curvature_contrast = bpy.props.FloatProperty(
        name="Contrast",
        description=(
            "Curvature intensity multiplier. 1.0 is the calibrated "
            "default; higher pushes ridges/creases harder."
        ),
        min=0.0, soft_max=4.0, max=8.0,
        default=2.0,
    )
    # Mix between the unblurred (sharp) and blurred (cavity) curvature
    # passes. 1.0 = pure edge highlights, 0.0 = pure broad cavity shading,
    # 0.65 default leans on edges but keeps enough cavity to read as a
    # texture-paint mask.
    bpy.types.Scene.aether_curvature_hard_weight = bpy.props.FloatProperty(
        name="Edge / Cavity",
        description=(
            "Balance between sharp edge highlights and broad cavity "
            "shading. 1.0 = only sharp edges, 0.0 = only cavity."
        ),
        min=0.0, max=1.0,
        default=0.65,
    )
    # Box-blur radius in pixels for the soft pass. Larger values catch
    # broader concavities at the cost of bleeding across nearby UV
    # islands. Small numbers (2-8) suit ~2K bakes; bump higher only on
    # 4K+ where 4 px is barely a pixel of real surface.
    bpy.types.Scene.aether_curvature_soft_radius = bpy.props.IntProperty(
        name="Cavity Radius",
        description=(
            "Pixel radius of the soft (cavity) curvature pass. Larger = "
            "broader, smoother cavity shading. Set to 0 to disable the "
            "soft pass entirely."
        ),
        min=0, soft_max=16, max=64,
        default=4,
    )

def unregister():
    bpy.utils.unregister_class(AETHER_OT_bake_source_maps)
    bpy.utils.unregister_class(AETHER_OT_open_export_dir)
    bpy.utils.unregister_class(AETHER_PT_bake_panel)
    del bpy.types.Scene.aether_target_obj
    del bpy.types.Scene.aether_source_obj
    del bpy.types.Scene.aether_use_highpoly
    del bpy.types.Scene.aether_bake_resolution
    del bpy.types.Scene.aether_curvature_contrast
    del bpy.types.Scene.aether_curvature_hard_weight
    del bpy.types.Scene.aether_curvature_soft_radius

if __name__ == "__main__":
    register()