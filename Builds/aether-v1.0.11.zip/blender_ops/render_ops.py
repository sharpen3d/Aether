# blender_ops/render_ops.py
# Author: Luke Stilson / sharpen3d

import bpy
import os
from bpy.types import Operator
from ..core import material_builder
from ..utils.shader_links import link_switcher_output
from ..utils import gpu_render


class EXPORTMAP_OT_render_all_maps(Operator):
    bl_idname = "exportmap.render_all_maps"
    bl_label = "Render All Maps"

    def execute(self, context):
        scene = context.scene
        export_list = scene.export_map_list
        
        revert_index = bpy.context.scene.export_map_index

        if not export_list:
            self.report({'WARNING'}, "No maps in export list")
            return {'CANCELLED'}

        original_view_transform = scene.view_settings.view_transform
        original_color_depth = scene.render.image_settings.color_depth
        original_color_mode = scene.render.image_settings.color_mode
        original_file_format = scene.render.image_settings.file_format
        original_filepath = scene.render.filepath

        output_dir = bpy.path.abspath(scene.export_output_directory)
        os.makedirs(output_dir, exist_ok=True)

        for item in export_list:
            # Socket relink
            if not link_switcher_output(item.map_type):
                self.report({'WARNING'}, f"Skipped '{item.map_name}': No output socket")
                continue

            # Set view transform
            scene.view_settings.view_transform = 'Raw' if item.map_type == 'NORMAL' else 'Standard'
            scene.render.image_settings.color_depth = item.bit_depth
            scene.render.image_settings.color_mode = {
                'R': 'BW',
                'RGB': 'RGB',
                'RGBA': 'RGBA',
            }[item.channel_format]
            scene.render.image_settings.file_format = 'PNG'

            filename = f"{scene.custom_object_name}{scene.delimiter}{item.map_name}.png"
            scene.render.filepath = os.path.join(output_dir, filename)
            self.report({'INFO'}, f"Rendering: {filename}")
            bpy.ops.render.render(write_still=True)

        # Restore original settings
        scene.view_settings.view_transform = original_view_transform
        scene.render.image_settings.color_depth = original_color_depth
        scene.render.image_settings.color_mode = original_color_mode
        scene.render.image_settings.file_format = original_file_format
        scene.render.filepath = original_filepath
        
        bpy.ops.exportmap.apply_map_settings(index=revert_index)

        preview_obj = next((o for o in scene.objects if ".stx_preview" in o.name), None)
        mat = material_builder.apply_rendered_maps_to_material(scene)
        if mat and preview_obj:
            #preview_obj.active_material = mat
            preview_obj.modifiers["GeometryNodes"]["Socket_3"] = mat

        self.report({'INFO'}, "All maps rendered")
        return {'FINISHED'}


class EXPORTMAP_OT_render_all_maps_gpu(Operator):
    """GPU-offscreen variant of Render All Maps.

    Runs the same per-map rewire+render loop as EXPORTMAP_OT_render_all_maps
    but uses gpu.types.GPUOffScreen.draw_view3d() to render through EEVEE_NEXT
    directly into a framebuffer, then a custom alpha-aware dilate shader to
    replace the compositor inpaint pass. Results land in bpy.data.images
    slots and (optionally) on disk via Image.save_render so the existing
    material_builder picks them up unchanged.
    """
    bl_idname = "exportmap.render_all_maps_gpu"
    bl_label = "Render All Maps (GPU)"
    bl_description = (
        "Fast preview render via gpu.GPUOffScreen + alpha-aware GPU dilate. "
        "Updates bpy.data.images slots and (optionally) writes them to disk. "
        "Cross-platform: Metal / Vulkan / OpenGL via the gpu module."
    )

    def execute(self, context):
        scene = context.scene
        export_list = scene.export_map_list
        revert_index = scene.export_map_index

        if not export_list:
            self.report({'WARNING'}, "No maps in export list")
            return {'CANCELLED'}

        camera = scene.camera
        if camera is None or camera.type != 'CAMERA':
            self.report({'ERROR'}, "Bake scene has no active camera")
            return {'CANCELLED'}

        win, area, region, space = gpu_render.find_view3d()
        if space is None:
            self.report(
                {'ERROR'},
                "GPU render needs an open 3D View. Switch to the Aether workspace and try again.",
            )
            return {'CANCELLED'}

        view_layer = scene.view_layers[0]
        width = scene.render.resolution_x
        height = scene.render.resolution_y
        dilate = int(getattr(scene, 'aether_gpu_dilate_distance', 8))
        save_to_disk = bool(getattr(scene, 'aether_gpu_save_to_disk', True))

        # Snapshot the bits of scene state we mutate.
        original_view_transform = scene.view_settings.view_transform
        original_color_depth = scene.render.image_settings.color_depth
        original_color_mode = scene.render.image_settings.color_mode
        original_file_format = scene.render.image_settings.file_format
        original_filepath = scene.render.filepath
        original_shading_type = space.shading.type

        # Rendered shading guarantees the EEVEE eval path runs through the
        # full material graph, regardless of what shading mode the artist
        # left the viewport in.
        space.shading.type = 'RENDERED'

        output_dir = bpy.path.abspath(scene.export_output_directory) if save_to_disk else None
        if save_to_disk:
            os.makedirs(output_dir, exist_ok=True)

        rendered_count = 0
        try:
            for item in export_list:
                if not link_switcher_output(item.map_type):
                    self.report({'WARNING'}, f"Skipped '{item.map_name}': no output socket")
                    continue

                # Match the disk path's view-transform logic exactly.
                scene.view_settings.view_transform = (
                    'Raw' if item.map_type == 'NORMAL' else 'Standard'
                )
                # Per-item settings only matter when we're saving to disk.
                if save_to_disk:
                    scene.render.image_settings.color_depth = item.bit_depth
                    scene.render.image_settings.color_mode = {
                        'R': 'BW', 'RGB': 'RGB', 'RGBA': 'RGBA',
                    }[item.channel_format]
                    scene.render.image_settings.file_format = 'PNG'

                # Force a depsgraph refresh so the switcher rewire takes
                # effect before the offscreen draw.
                bpy.context.view_layer.update()

                rendered = gpu_render.render_map_offscreen(
                    scene, view_layer, space, region, camera,
                    width, height, do_color_management=True,
                )
                try:
                    if dilate > 0:
                        dilated = gpu_render.dilate_offscreen(rendered, width, height, dilate)
                    else:
                        dilated = rendered
                    try:
                        filename = (
                            f"{scene.custom_object_name}{scene.delimiter}{item.map_name}.png"
                        )
                        # In-memory image slot — the .stxmat material will
                        # reference this. Float buffer so 16/32-bit maps
                        # don't quantise on the way through.
                        img = gpu_render.ensure_aether_image(
                            filename, width, height, float_buffer=True
                        )
                        # Normal maps must stay non-color in the data block,
                        # base color stays sRGB. Match the disk path.
                        if item.map_type == 'NORMAL':
                            img.colorspace_settings.name = 'Non-Color'
                        else:
                            img.colorspace_settings.name = 'sRGB'

                        gpu_render.push_offscreen_into_image(dilated, img)

                        if save_to_disk:
                            filepath = os.path.join(output_dir, filename)
                            scene.render.filepath = filepath
                            gpu_render.save_image_to_disk(img, filepath, scene)
                    finally:
                        if dilated is not rendered:
                            dilated.free()
                finally:
                    rendered.free()

                rendered_count += 1
                self.report({'INFO'}, f"GPU rendered: {item.map_name}")
        finally:
            # Restore everything we touched, even if a map failed mid-loop.
            scene.view_settings.view_transform = original_view_transform
            scene.render.image_settings.color_depth = original_color_depth
            scene.render.image_settings.color_mode = original_color_mode
            scene.render.image_settings.file_format = original_file_format
            scene.render.filepath = original_filepath
            space.shading.type = original_shading_type

        # Re-apply the previously-selected map's switcher wiring so the live
        # viewport returns to whatever the artist had focused.
        bpy.ops.exportmap.apply_map_settings(index=revert_index)

        # Rebuild the .stxmat preview material. The (modified) builder picks
        # up our in-memory images by name, so this works whether or not we
        # also wrote to disk.
        preview_obj = next((o for o in scene.objects if ".stx_preview" in o.name), None)
        mat = material_builder.apply_rendered_maps_to_material(scene)
        if mat and preview_obj and "GeometryNodes" in preview_obj.modifiers:
            try:
                preview_obj.modifiers["GeometryNodes"]["Socket_3"] = mat
            except (KeyError, TypeError):
                pass

        self.report({'INFO'}, f"GPU render complete ({rendered_count} maps)")
        return {'FINISHED'}


def register():
    bpy.utils.register_class(EXPORTMAP_OT_render_all_maps)
    bpy.utils.register_class(EXPORTMAP_OT_render_all_maps_gpu)


def unregister():
    bpy.utils.unregister_class(EXPORTMAP_OT_render_all_maps_gpu)
    bpy.utils.unregister_class(EXPORTMAP_OT_render_all_maps)
