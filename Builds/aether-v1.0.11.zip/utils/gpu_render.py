# utils/gpu_render.py
# Author: Luke Stilson / sharpen3d
"""GPU-offscreen render path for Aether.

Render flow per map:
  1. link_switcher_output(map_type) rewires aether_switcher.<MapType> ->
     aether_master.Output (existing helper, unchanged).
  2. scene.view_settings.view_transform is set to 'Raw' for NORMAL maps and
     'Standard' otherwise so GPUOffScreen.draw_view3d(do_color_management=True)
     emits correctly-encoded pixels.
  3. A GPUOffScreen is allocated at scene.render.resolution_x/y. EEVEE_NEXT
     evaluates the rewired aether_master shader straight into the framebuffer
     when called via draw_view3d() with the bake camera matrices.
  4. An alpha-aware single-step dilation shader is run N times to extend
     opaque pixels outward by N texels. This replaces the old compositor
     CompositorNodeInpaint(distance=resolution_x) which was the dominant
     bottleneck on the existing render path.
  5. Pixels are read back via texture_color.read() and pushed into a
     bpy.data.images slot via Image.pixels.foreach_set(). The slot can then
     be saved to disk (Image.save_render with scene image_settings) or kept
     purely in-memory for fast iteration.

Cross-platform notes (macOS / Linux / Windows):
  - All GPU access goes through the high-level `gpu` module. No `bgl` (the
    deprecated GL wrapper, removed in Blender 4.x). No raw GL extensions.
  - The dilate shader is built with `gpu.types.GPUShaderCreateInfo`, which
    Blender's shader compiler translates to Metal (macOS), Vulkan, or
    OpenGL as appropriate for the active backend.
  - Projection matrix comes from `Object.calc_matrix_camera`, which handles
    both ORTHO and PERSP cameras and bakes in the resolution-dependent
    aspect ratio.
  - Texture format is RGBA16F — supported on every backend Blender ships.
"""

import bpy
import gpu
from gpu_extras.batch import batch_for_shader

from .shader_links import link_switcher_output  # re-exported for callers


# ---------------------------------------------------------------------------
# Dilate shader
# ---------------------------------------------------------------------------
# Single-step: if center pixel has alpha < 1, average opaque 8-neighbours
# (in a 3x3 stencil at one texel offset) and emit the average with alpha=1.
# Run N iterations -> dilation distance == N texels. For N=8 at 2K res that
# is well under one millisecond per pass on any modern GPU.

_DILATE_VERT = """
void main()
{
    uv_interp = uv;
    gl_Position = vec4(pos, 0.0, 1.0);
}
"""

_DILATE_FRAG = """
void main()
{
    vec4 c = texture(source_tex, uv_interp);
    if (c.a > 0.99) {
        FragColor = c;
        return;
    }

    vec3 acc = vec3(0.0);
    float w = 0.0;

    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            if (x == 0 && y == 0) { continue; }
            vec2 off = vec2(float(x), float(y)) * texel_size;
            vec4 s = texture(source_tex, uv_interp + off);
            if (s.a > 0.99) {
                acc += s.rgb;
                w += 1.0;
            }
        }
    }

    if (w > 0.0) {
        FragColor = vec4(acc / w, 1.0);
    } else {
        FragColor = c;
    }
}
"""

_dilate_shader = None
_dilate_batch = None


def _get_dilate_shader():
    global _dilate_shader, _dilate_batch
    if _dilate_shader is not None:
        return _dilate_shader, _dilate_batch

    vert_out = gpu.types.GPUStageInterfaceInfo("aether_dilate_iface")
    vert_out.smooth('VEC2', 'uv_interp')

    info = gpu.types.GPUShaderCreateInfo()
    info.push_constant('VEC2', 'texel_size')
    info.sampler(0, 'FLOAT_2D', 'source_tex')
    info.vertex_in(0, 'VEC2', 'pos')
    info.vertex_in(1, 'VEC2', 'uv')
    info.vertex_out(vert_out)
    info.fragment_out(0, 'VEC4', 'FragColor')
    info.vertex_source(_DILATE_VERT)
    info.fragment_source(_DILATE_FRAG)

    _dilate_shader = gpu.shader.create_from_info(info)
    _dilate_batch = batch_for_shader(
        _dilate_shader,
        'TRI_STRIP',
        {
            "pos": ((-1, -1), (1, -1), (-1, 1), (1, 1)),
            "uv": ((0, 0), (1, 0), (0, 1), (1, 1)),
        },
    )
    # Drop the descriptor objects now that the shader is compiled.
    del vert_out, info
    return _dilate_shader, _dilate_batch


# ---------------------------------------------------------------------------
# Passthrough blit (for seeding the ping-pong from a draw_view3d result)
# ---------------------------------------------------------------------------

_passthrough_shader = None
_passthrough_batch = None


def _draw_passthrough(texture):
    """Draw `texture` as a fullscreen quad into the currently bound framebuffer."""
    global _passthrough_shader, _passthrough_batch
    if _passthrough_shader is None:
        _passthrough_shader = gpu.shader.from_builtin('IMAGE')
        _passthrough_batch = batch_for_shader(
            _passthrough_shader,
            'TRI_STRIP',
            {
                "pos": ((-1, -1), (1, -1), (-1, 1), (1, 1)),
                "texCoord": ((0, 0), (1, 0), (0, 1), (1, 1)),
            },
        )
    _passthrough_shader.bind()
    _passthrough_shader.uniform_sampler('image', texture)
    _passthrough_batch.draw(_passthrough_shader)


# ---------------------------------------------------------------------------
# Viewport / camera plumbing
# ---------------------------------------------------------------------------

def find_view3d():
    """Return (window, area, region, space) for the first usable VIEW_3D area.

    Searches every open window so we still work if the artist is in a
    different workspace than the Aether one. Returns (None, None, None, None)
    if nothing usable is open.
    """
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            space = next((s for s in area.spaces if s.type == 'VIEW_3D'), None)
            region = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if space and region:
                return win, area, region, space
    return None, None, None, None


def _camera_matrices(camera_obj, depsgraph, width, height):
    """View + projection matrices for the bake camera.

    `Object.calc_matrix_camera` handles both ORTHO and PERSP cameras and
    bakes in the resolution-dependent aspect ratio. Doing it this way means
    we don't have to special-case the ortho_scale plumbing here — it just
    works for whatever the artist sets on the camera.
    """
    view_matrix = camera_obj.matrix_world.inverted()
    projection_matrix = camera_obj.calc_matrix_camera(
        depsgraph, x=width, y=height, scale_x=1.0, scale_y=1.0
    )
    return view_matrix, projection_matrix


# ---------------------------------------------------------------------------
# Core render
# ---------------------------------------------------------------------------

def render_map_offscreen(scene, view_layer, view3d, region, camera_obj,
                          width, height, do_color_management=True):
    """Render the current bake-scene shader into a fresh GPUOffScreen.

    Caller owns the returned offscreen and must call .free() when done.
    """
    depsgraph = bpy.context.evaluated_depsgraph_get()
    view_matrix, projection_matrix = _camera_matrices(camera_obj, depsgraph, width, height)

    offscreen = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
    offscreen.draw_view3d(
        scene=scene,
        view_layer=view_layer,
        view3d=view3d,
        region=region,
        view_matrix=view_matrix,
        projection_matrix=projection_matrix,
        do_color_management=do_color_management,
    )
    return offscreen


def dilate_offscreen(source_offscreen, width, height, iterations):
    """Run an N-iteration alpha-aware dilate. Returns a fresh offscreen
    holding the dilated result. The source offscreen is not modified.
    """
    if iterations <= 0:
        # No-op: return a copy so the caller can free symmetrically.
        copy = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
        with copy.bind():
            _draw_passthrough(source_offscreen.texture_color)
        return copy

    shader, batch = _get_dilate_shader()
    texel = (1.0 / float(width), 1.0 / float(height))

    a = gpu.types.GPUOffScreen(width, height, format='RGBA16F')
    b = gpu.types.GPUOffScreen(width, height, format='RGBA16F')

    # Seed `a` from the source render.
    with a.bind():
        _draw_passthrough(source_offscreen.texture_color)

    src, dst = a, b
    for _ in range(int(iterations)):
        with dst.bind():
            shader.bind()
            shader.uniform_sampler('source_tex', src.texture_color)
            shader.uniform_float('texel_size', texel)
            batch.draw(shader)
        src, dst = dst, src

    # `src` holds the latest result; free the unused buffer.
    if dst is a:
        a.free()
        return b
    else:
        b.free()
        return a


# ---------------------------------------------------------------------------
# Image slot management
# ---------------------------------------------------------------------------

def ensure_aether_image(name, width, height, float_buffer=True):
    """Get-or-create a bpy.data.images slot used as the GPU readback target.

    If a slot of the same name exists with mismatched dimensions we replace
    it (rather than silently writing the wrong-sized buffer into it).
    """
    img = bpy.data.images.get(name)
    if img is not None and (img.size[0] != width or img.size[1] != height):
        bpy.data.images.remove(img, do_unlink=False)
        img = None
    if img is None:
        img = bpy.data.images.new(
            name, width=width, height=height, alpha=True, float_buffer=float_buffer
        )
    return img


def push_offscreen_into_image(offscreen, image):
    """Read the offscreen's color attachment and stuff the float pixels
    into `image`. Both Blender Image.pixels and GPUOffScreen.texture_color
    use bottom-left origin, so no flip is required.
    """
    buf = offscreen.texture_color.read()
    # gpu.types.Buffer supports the buffer protocol since 3.x, so
    # foreach_set can consume it directly without a Python-level copy.
    image.pixels.foreach_set(buf)
    image.update()


def save_image_to_disk(image, filepath, scene):
    """Persist `image` to disk via Image.save_render so it picks up the
    scene's render.image_settings (color depth, color mode, file format).
    Returns True on success.
    """
    image.filepath_raw = filepath
    try:
        image.save_render(filepath, scene=scene)
        return True
    except Exception as exc:
        print(f"[Aether GPU] Failed to save {filepath}: {exc}")
        return False


# ---------------------------------------------------------------------------
# Module registration (no classes; provided for parity with sibling modules)
# ---------------------------------------------------------------------------

def register():
    pass


def unregister():
    pass
